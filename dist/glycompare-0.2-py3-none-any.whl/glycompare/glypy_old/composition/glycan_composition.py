from glypy.structure.glycan_composition import *
import warnings

warnings.warn("glycan_compostion has been moved to glypy.structure", stacklevel=2)
