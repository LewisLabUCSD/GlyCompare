__all__ = ["synonyms", "identity"]
