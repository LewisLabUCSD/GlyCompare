Please check https://github.com/LewisLabUCSD/GlyCompare


